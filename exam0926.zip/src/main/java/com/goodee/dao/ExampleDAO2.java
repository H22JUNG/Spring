package com.goodee.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.goodee.vo.TestVO2;

@Mapper
public interface ExampleDAO2 {
	
	public List<TestVO2> getlist();
	
	public int setdata(Map<String, String> map);
	public int setdataFatch(TestVO2 vo);
	
	public int updatedata(Map<String, String> map);
	public int updatedata2(Map<String, String> map);
	
	public int delete8(int id);
	public int delete9(Map<String, String> map);
}
