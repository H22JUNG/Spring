package com.goodee.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.goodee.service.ExampleService2;
import com.goodee.vo.TestVO1;
import com.goodee.vo.TestVO2;

@Controller
@RequestMapping("/example2") // 수정하지 말 것
public class ExampleController2 {
	
	private ExampleService2 service;
	
	public ExampleController2(ExampleService2 service) {
		super();
		this.service = service;
	}
	
	// 1번 문제
	@RequestMapping
	public String index(Model model) {
		model.addAttribute("list", service.getlist());
		return "example2/index";
	}
	
	// 2번 문제
	@GetMapping("/result1")
	public String result1(@RequestParam Map<String, String> map){
		service.exam2(map);
		return "redirect:/example2";
	}
	
	// 3번 문제
	@PostMapping("/result2")
	public String result2(@RequestParam Map<String, String> map) {
		service.exam2(map);
		return "redirect:/example2";
	}
	
	// 4번 문제
	@PostMapping("/result3")
	@ResponseBody
	public int result3(@RequestBody Map<String, String> map) {
		
		return service.exam2(map);
	}
	
	// 5번 문제
	@PostMapping("/result4")
	public int result4(@RequestParam Map<String, String> map) {
		
		return service.exam5(map);
	}
	
	// 6번 문제
	@PostMapping("/result5")
	public String result5(@RequestParam Map<String, String> map) {
		service.exam6(map);
		return "redirect:/example2";
	}
	
	// 7번 문제 - 1 페이지 이동
	@PostMapping("/move6")
	public String move6(@RequestParam int id, 
			@ModelAttribute("testVO2") TestVO2 vo,
			Model model) {
		model.addAttribute("id", id);
		return "example2/result/result1";
	}
	
	// 7번 문제 - 2 업데이트 진행
	@PostMapping("/move7")
	public String result6(@RequestParam Map<String, String> map) {
		service.exam5(map);
		return "redirect:/example2";
	}
	
	// 8번 문제
	@PostMapping("/result7")
	public String result7(@RequestParam int id) {
		service.delete8(id);
		return "redirect:/example2";
	}
	
	// 9번 문제
	@PostMapping("/result8")
	public String result8(@RequestParam Map<String, String> map) {
		service.delete9(map);
		return "redirect:/example2";
	}
}
