package com.goodee.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import com.goodee.dao.ExampleDAO2;
import com.goodee.vo.TestVO2;

@Service
public class ExampleService2 {
	
	private ExampleDAO2 dao;

	public ExampleService2(ExampleDAO2 dao) {
		super();
		this.dao = dao;
	}
	
	public List<TestVO2> getlist() {
		return dao.getlist();
	}
	
	public int exam2(Map<String, String> map) {
		return dao.setdata(map);
	}
	
	public int exam4(@Param("testVO2")TestVO2 vo) {
		return dao.setdataFatch(vo);
	}
	
	public int exam5(Map<String, String> map) {
		return dao.updatedata(map);
	}
	public int exam6(Map<String, String> map) {
		return dao.updatedata2(map);
	}
	
	public int delete8(int id) {
		return dao.delete8(id);
	}
	public int delete9(Map<String, String> map) {
		return dao.delete9(map);
	}
}
